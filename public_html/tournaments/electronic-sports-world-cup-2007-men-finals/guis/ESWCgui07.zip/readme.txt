ES World Cup CS 1.6 Gui v2.0
Please report any bug at gui@eswc.com

Install instruction:

HALFLIFE COUNTER STRIKE 1.6 HAVE TO BE INSTALL BEFORE.

Unzip all files in the "Counter-Strike" directory of Steam/SteamApps/User account/Counter-Strike.
The new gui will be activated immediatly.

Questions and comments:
gui@eswc.com



//Release details
*** 2.0 (02-04-07) ***
Gfx update

*** 1.1 (17-05-04) Lan ***
RadarType selection added

*** 1.0 (14-05-04) Lan ***
ex_interp forced to 0.01
default rate is 20000
default cl_updaterate is 101
default cl_cmdrate is 101

*** 0.5b (14-04-04) ***
s_eax "0" by default.
bind toggleconsole added.

*** 0.4b (02-04-04) ***
Shield alias removed.
Shield in buy menu removed.
Support Multi-language (partial).
Fixed graphical variable.
Remove useless variable in Multiplayer/Advanced.
kb_act.lst :
	- remove "blank" lines
	- change names in keyboard section

*** 0.3b (10-03-04) ***
Userconfig.cfg :
	- add demo alias
	- quick switch weapon alias modified
	- default ex_interp is 0.01
User.scr :
	- ex_interp can be changed by user
	- cl_hidefrags removed
New background

*** 0.2b (02-02-04) ***
User.scr bug correction.
Add ESWC logo as spray.

*** 0.1b (01-02-04) ***
First release